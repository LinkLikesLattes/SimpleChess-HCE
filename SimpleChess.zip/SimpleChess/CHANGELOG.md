# Changelog

Release history for Simple Chess. An entry is added here whenever a tested candidate is promoted to the live `simplechess` binary via `tools/version.py promote`. Every version — accepted or not — is also kept as a runnable binary in `versions/`.

<!-- new entries inserted below this line by `version.py promote` -->

## v1.0 — 2026-07-18

- Self-reports: `Simple Chess 1.0`
- Source VERSION at save time: `1.0`

threats eval (classical design): strongly-protected/weak classification, minor/rook/king attacks by victim, hanging pieces (LPDO), safe pawn attacks + push threats; SC_THREAT=50 sequential-sweep winner (+70 Elo @ 60ms/200g vs v0.9, LOS 100%). Tree 0.48x.

## v0.9 — 2026-07-18

- Self-reports: `Simple Chess 0.9`
- Source VERSION at save time: `0.9`

no-increment time mgmt fix: for inc==0, spend 30% less/move + cap max at 2x optimum and 5% of clock (was 10%). Worst-case move at 60s no-inc 4.3s->2.1s. Increment/depth play unchanged (search identical to v0.8).

## v0.8 — 2026-07-17

- Self-reports: `Simple Chess 0.8`
- Source VERSION at save time: `0.8`

integrated king safety (extends v0.3 king-attack): shelter/exposure (queen-gated, hide-in-pawns), own-piece crowding, enemy denial + no-escape penalty, inactive-king-when-queens-off; SC_KSAFE=200 sweep winner (+89 Elo @ depth10/200g vs v0.7, LOS 100%)

## v0.7 — 2026-07-17

- Self-reports: `Simple Chess 0.7`
- Source VERSION at save time: `0.7`

adaptive continuous search width (SF-style): root-gap x score x phase signal scales LMR/LMP/futility; endgames+decisive stay full-depth; SC_BREADTH=64 sweep winner (+38 Elo @ 60ms/100g vs v0.6, curve peak of 32-160)

## v0.6 — 2026-07-17

- Self-reports: `Simple Chess 0.6`
- Source VERSION at save time: `0.6`

clock: SF-style ply-scaled time allocation (less in opening), hard cap min(60s,10% remaining); only-move early exit (>=100cp over 2nd best, stable, depth>=16, real clock only)

## v0.5 — 2026-07-17

- Self-reports: `Simple Chess 0.5`
- Source VERSION at save time: `0.5`

Lazy SMP multithreading: shared TT, per-thread history/PV, main-thread TM, helper depth-stagger; Threads option default 8 (7.4x nps @ 8T)

## v0.4 — 2026-07-17

- Self-reports: `Simple Chess 0.4`
- Source VERSION at save time: `0.4`

pawn structure: doubled/isolated penalties, rank-scaled passers (blockade/support aware), EG advancement; scale-175 sweep winner (+106 Elo @ depth8/216g vs v0.3). Gauntlet 100g@60ms: +235 vs v0.1, +123 vs v0.2, +78 vs v0.3.

## v0.3 — 2026-07-16

- Self-reports: `Simple Chess 0.3`
- Source VERSION at save time: `0.3`

king-attack eval, amplitude-swept (katt67 best of 5 @ depth8/216g): +31 Elo @ depth 8, +-0 @ 60ms (358g pooled each)
