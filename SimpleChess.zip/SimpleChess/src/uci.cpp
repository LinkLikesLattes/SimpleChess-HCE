// -----------------------------------------------------------------------------
// uci.cpp
//
// UCI command dispatch. Each recognised command maps to a small handler; unknown
// tokens are ignored, as the protocol requires. Only the commands a typical GUI
// needs are implemented, plus a couple of debug conveniences (`d`).
// -----------------------------------------------------------------------------

#include "uci.hpp"

#include <algorithm>
#include <iostream>

#include "evaluate.hpp"

namespace engine {

UCI::UCI(std::filesystem::path exe_dir) : search_(tt_), exe_dir_(std::move(exe_dir)) {
    eval::init();
    tt_.resize(hash_mb_);
    board_ = Board(chess::constants::STARTPOS);
    try_load_default_book();
}

void UCI::try_load_default_book() {
    const std::filesystem::path candidates[] = {
        exe_dir_ / "books" / "book.bin",
        exe_dir_ / "book.bin",
        std::filesystem::path("books") / "book.bin",
        std::filesystem::path("book.bin"),
    };
    for (const auto& candidate : candidates) {
        if (book_.load(candidate)) return;
    }
    // No book at any default location: play normally, without comment — this
    // is a fully supported configuration, not an error.
}

void UCI::handle_uci() const {
    std::cout << "id name " << kEngineName << '\n';
    std::cout << "id author " << kEngineAuthor << '\n';

    // Advertise supported options with their type/range so GUIs can render them.
    std::cout << "option name Hash type spin default 16 min 1 max 4096\n";
    std::cout << "option name Threads type spin default " << Search::kDefaultThreads
              << " min 1 max " << Search::kMaxThreads << "\n";
    std::cout << "option name Move Overhead type spin default 30 min 0 max 5000\n";
    std::cout << "option name Ponder type check default false\n";
    std::cout << "option name Clear Hash type button\n";
    std::cout << "option name OwnBook type check default true\n";
    std::cout << "option name Book File type string default books/book.bin\n";
    std::cout << "uciok" << std::endl;
}

void UCI::handle_isready() const { std::cout << "readyok" << std::endl; }

void UCI::handle_newgame() {
    search_.new_game();  // joins any running search, clears history heuristics
    tt_.clear();
    board_ = Board(chess::constants::STARTPOS);
}

void UCI::handle_setoption(std::istringstream& is) {
    // Grammar: setoption name <name...> [value <value...>]
    std::string token, name, value;
    is >> token;  // expect "name"

    // Collect the (possibly multi-word) option name up to "value".
    while (is >> token && token != "value") {
        if (!name.empty()) name += ' ';
        name += token;
    }
    // Collect the (possibly multi-word) value.
    while (is >> token) {
        if (!value.empty()) value += ' ';
        value += token;
    }

    auto iequals = [](std::string a, std::string b) {
        auto lower = [](std::string& s) {
            std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
        };
        lower(a);
        lower(b);
        return a == b;
    };

    if (iequals(name, "Hash")) {
        // Never reallocate the table under a running search.
        search_.stop();
        search_.wait();
        hash_mb_ = static_cast<std::size_t>(std::max(1, std::stoi(value)));
        tt_.resize(hash_mb_);
    } else if (iequals(name, "Threads")) {
        threads_ = std::clamp(std::stoi(value), 1, Search::kMaxThreads);
        search_.set_threads(threads_);  // joins any running search first
    } else if (iequals(name, "Move Overhead")) {
        move_overhead_ = std::clamp(std::stoi(value), 0, 5000);
    } else if (iequals(name, "Ponder")) {
        ponder_ = iequals(value, "true");
    } else if (iequals(name, "Clear Hash")) {
        search_.stop();
        search_.wait();
        tt_.clear();
    } else if (iequals(name, "OwnBook")) {
        own_book_ = iequals(value, "true");
    } else if (iequals(name, "Book File")) {
        // An explicit path that fails to load just leaves the book unloaded
        // (own_book_ then has nothing to serve) — no book is a normal state.
        book_.load(value);
    }
    // Unknown options are silently ignored per the protocol.
}

void UCI::handle_position(std::istringstream& is) {
    std::string token;
    is >> token;

    if (token == "startpos") {
        board_ = Board(chess::constants::STARTPOS);
        is >> token;  // consume optional "moves"
    } else if (token == "fen") {
        // Reassemble the six-field FEN that follows.
        std::string fen;
        while (is >> token && token != "moves") {
            fen += token;
            fen += ' ';
        }
        board_ = Board(fen);
        // token now holds "moves" (or is exhausted).
    } else {
        return;  // malformed
    }

    if (token == "moves") {
        while (is >> token) {
            const Move m = chess::uci::uciToMove(board_, token);
            if (m == Move(Move::NO_MOVE)) break;  // stop on an unparseable move
            board_.makeMove(m);
        }
    }
}

void UCI::handle_go(std::istringstream& is) {
    SearchLimits limits;
    std::string  token;

    while (is >> token) {
        if (token == "wtime") {
            is >> limits.time[static_cast<int>(Color::WHITE)];
        } else if (token == "btime") {
            is >> limits.time[static_cast<int>(Color::BLACK)];
        } else if (token == "winc") {
            is >> limits.inc[static_cast<int>(Color::WHITE)];
        } else if (token == "binc") {
            is >> limits.inc[static_cast<int>(Color::BLACK)];
        } else if (token == "movestogo") {
            is >> limits.movestogo;
        } else if (token == "depth") {
            is >> limits.depth;
        } else if (token == "nodes") {
            is >> limits.nodes;
        } else if (token == "movetime") {
            is >> limits.movetime;
        } else if (token == "mate") {
            is >> limits.mate;
        } else if (token == "infinite") {
            limits.infinite = true;
        } else if (token == "ponder") {
            limits.ponder = true;
        }
        // `searchmoves` is not yet supported and is intentionally ignored.
    }

    // A previous search's worker thread must be fully stopped before we can
    // either answer from the book or start a new one — otherwise a late
    // bestmove from that thread could land after ours and violate the
    // protocol's one-bestmove-per-go contract.
    search_.stop();
    search_.wait();

    if (own_book_ && book_.loaded()) {
        const Move book_move = book_.probe(board_);
        if (book_move != Move(Move::NO_MOVE)) {
            std::cout << "info string book move" << std::endl;
            std::cout << "bestmove " << chess::uci::moveToUci(book_move) << std::endl;
            return;
        }
    }

    search_.start(board_, limits);
}

void UCI::handle_print() const {
    // Human-readable board dump for debugging (non-standard convenience).
    std::cout << board_ << "\nFen: " << board_.getFen() << "\nKey: " << std::hex << board_.hash()
              << std::dec << std::endl;
}

void UCI::loop() {
    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream is(line);
        std::string        command;
        is >> command;

        if (command.empty()) {
            continue;
        } else if (command == "uci") {
            handle_uci();
        } else if (command == "isready") {
            handle_isready();
        } else if (command == "ucinewgame") {
            handle_newgame();
        } else if (command == "setoption") {
            handle_setoption(is);
        } else if (command == "position") {
            handle_position(is);
        } else if (command == "go") {
            handle_go(is);
        } else if (command == "stop") {
            search_.stop();
        } else if (command == "ponderhit") {
            // The pondered move was played: transition to a normal timed search.
            // The current shell simply keeps searching; refine when pondering lands.
        } else if (command == "d" || command == "print") {
            handle_print();
        } else if (command == "eval") {
            // Debug convenience: static eval of the current position,
            // from the side to move's perspective.
            std::cout << "static eval (stm pov): " << eval::evaluate(board_) << " cp"
                      << std::endl;
        } else if (command == "quit" || command == "exit") {
            search_.stop();
            search_.wait();
            break;
        }
        // Unknown commands are ignored, as required by the protocol.
    }
}

}  // namespace engine
