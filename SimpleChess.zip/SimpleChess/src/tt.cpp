// -----------------------------------------------------------------------------
// tt.cpp
//
// Transposition table implementation. The replacement policy is intentionally
// simple (depth-preferred with aging) — enough to be correct and useful, and an
// obvious place to iterate once the search matures.
// -----------------------------------------------------------------------------

#include "tt.hpp"

#include <bit>
#include <cstring>

namespace engine {

namespace {
// Mate scores are stored distance-to-mate from the *root*. When an entry is
// written from a node `ply` deep, we normalise to be root-relative; on read we
// convert back. These helpers keep that logic in one place.
Value value_to_tt(Value v, int ply) {
    if (v >= VALUE_MATE_IN_MAX_PLY) return v + ply;
    if (v <= VALUE_MATED_IN_MAX_PLY) return v - ply;
    return v;
}
}  // namespace

void TranspositionTable::resize(std::size_t mb) {
    const std::size_t bytes        = mb * 1024 * 1024;
    std::size_t       want_entries = bytes / sizeof(TTEntry);
    if (want_entries < 1) want_entries = 1;

    // Round down to a power of two so index_for() can mask.
    count_ = std::bit_floor(want_entries);

    table_.assign(count_, TTEntry{});
    generation_ = 0;
}

void TranspositionTable::clear() {
    std::fill(table_.begin(), table_.end(), TTEntry{});
    generation_ = 0;
}

void TranspositionTable::new_search() {
    // Step by 4 so the low two bits stay free for the Bound flag.
    generation_ += 4;
}

TTProbe TranspositionTable::probe(Key key) {
    if (count_ == 0) return {false, nullptr};

    TTEntry* entry = &table_[index_for(key)];
    const auto tag = static_cast<std::uint16_t>(key >> 48);

    if (entry->bound() != Bound::NONE && entry->key16 == tag) {
        return {true, entry};
    }
    return {false, entry};
}

void TranspositionTable::store(Key key, Value value, Value eval, Bound bound, Depth depth, Move move,
                               int ply) {
    if (count_ == 0) return;

    TTEntry*   entry = &table_[index_for(key)];
    const auto tag   = static_cast<std::uint16_t>(key >> 48);

    // Preserve an existing best move if this store doesn't carry one (e.g. a
    // fail-low that never found a move worth recording).
    if (move != Move(Move::NO_MOVE) || entry->key16 != tag) {
        entry->move16 = static_cast<std::uint16_t>(move.move());
    }

    // Depth-preferred replacement with aging: always overwrite a stale entry (a
    // different position or an older generation); otherwise keep the shallower
    // search only if the newcomer searched at least as deep.
    const bool replace = entry->bound() == Bound::NONE || entry->key16 != tag ||
                         entry->generation() != generation_ ||
                         depth + 2 >= static_cast<Depth>(entry->depth) || bound == Bound::EXACT;

    if (!replace) return;

    entry->key16     = tag;
    entry->value     = static_cast<std::int16_t>(value_to_tt(value, ply));
    entry->eval      = static_cast<std::int16_t>(eval);
    entry->depth     = static_cast<std::uint8_t>(depth < 0 ? 0 : depth);
    entry->gen_bound = static_cast<std::uint8_t>(generation_ | static_cast<std::uint8_t>(bound));
}

int TranspositionTable::hashfull() const {
    if (count_ == 0) return 0;

    // Sample the first 1000 slots as a cheap estimate, matching common practice.
    const std::size_t sample = count_ < 1000 ? count_ : 1000;
    int               used   = 0;
    for (std::size_t i = 0; i < sample; ++i) {
        if (table_[i].bound() != Bound::NONE && table_[i].generation() == generation_) ++used;
    }
    return static_cast<int>(static_cast<std::size_t>(used) * 1000 / sample);
}

}  // namespace engine
