#pragma once

// -----------------------------------------------------------------------------
// tt.hpp
//
// Transposition table. This is a shell: the storage, indexing, and replacement
// plumbing are in place so search can call probe()/store() today, but the eval
// and search that populate it are still to come. The bound flags and packed
// entry layout match what a standard alpha-beta search expects.
// -----------------------------------------------------------------------------

#include <cstddef>
#include <cstdint>
#include <vector>

#include "types.hpp"

namespace engine {

// The kind of score stored in an entry, relative to the search window that
// produced it. EXACT is a PV score; LOWER/UPPER are fail-high/fail-low bounds.
enum class Bound : std::uint8_t {
    NONE  = 0,
    UPPER = 1,  // score is an upper bound (fail-low, alpha)
    LOWER = 2,  // score is a lower bound (fail-high, beta)
    EXACT = 3,  // score is exact (PV node)
};

// A single table slot. Kept small and trivially copyable so a cluster fits in a
// cache line. `key16` stores the high bits of the zobrist key so we can detect
// collisions without paying for a full 64-bit key per entry.
struct TTEntry {
    std::uint16_t key16    = 0;              // upper 16 bits of the position key
    std::uint16_t move16   = 0;              // best/refutation move (Move encoding)
    std::int16_t  value    = 0;              // score, root-relative on store
    std::int16_t  eval     = 0;              // static eval (for lazy re-use)
    std::uint8_t  depth    = 0;              // search depth this entry was made at
    std::uint8_t  gen_bound = 0;             // generation (upper 6 bits) + Bound (low 2)

    [[nodiscard]] Bound bound() const noexcept { return static_cast<Bound>(gen_bound & 0x3); }
    [[nodiscard]] std::uint8_t generation() const noexcept { return gen_bound & 0xFC; }
};

// Result of a probe: whether we hit, and a view of the entry we landed on so the
// caller can decide how to use it (cutoff, move ordering, static eval).
struct TTProbe {
    bool     hit   = false;
    TTEntry* entry = nullptr;
};

class TranspositionTable {
   public:
    TranspositionTable() = default;

    // (Re)allocate the table to `mb` megabytes, rounding down to a power-of-two
    // entry count. Clears all entries. Called on `setoption Hash` and startup.
    void resize(std::size_t mb);

    // Zero every entry. Called on `ucinewgame`.
    void clear();

    // Bump the age counter so entries from previous searches become preferred
    // replacement victims. Called once per `go`.
    void new_search();

    // Look up `key`. On a hit, `entry` points at live storage the caller may
    // read; on a miss it points at the slot that store() would overwrite.
    [[nodiscard]] TTProbe probe(Key key);

    // Insert/replace an entry. Implementation of the replacement policy lives in
    // the .cpp; for now it is a straightforward depth-preferred scheme.
    void store(Key key, Value value, Value eval, Bound bound, Depth depth, Move move, int ply);

    // Rough fullness in permille (0..1000), for UCI `info hashfull`.
    [[nodiscard]] int hashfull() const;

   private:
    [[nodiscard]] std::size_t index_for(Key key) const noexcept {
        // count_ is a power of two, so mask instead of modulo.
        return static_cast<std::size_t>(key) & (count_ - 1);
    }

    std::vector<TTEntry> table_;
    std::size_t          count_      = 0;  // number of entries (power of two)
    std::uint8_t         generation_ = 0;  // current search age, steps of 4
};

}  // namespace engine
