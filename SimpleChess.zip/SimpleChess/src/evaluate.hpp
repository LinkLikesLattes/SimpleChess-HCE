#pragma once

// -----------------------------------------------------------------------------
// evaluate.hpp
//
// Hand-crafted evaluation (HCE) entry point. This is the surface a solid HCE is
// meant to grow behind: today it returns a tapered material + piece-square-table
// score so the search plays sensible, legal chess, but the intent is for terms
// like mobility, king safety, pawn structure, and threats to be layered in here
// without any change to the search that consumes it.
//
// Contract: evaluate() returns a score in centipawns from the perspective of the
// side to move (positive == good for the mover). Search negates across plies, so
// keeping this side-relative is essential.
// -----------------------------------------------------------------------------

#include "types.hpp"

namespace engine::eval {

// Static evaluation of a quiet-ish position. Must be symmetric: evaluating a
// mirrored position for the other side should return the negated score.
[[nodiscard]] Value evaluate(const Board& board);

// Called once at startup so the evaluation can precompute tables (PSTs, etc.).
// Safe to call more than once.
void init();

}  // namespace engine::eval
