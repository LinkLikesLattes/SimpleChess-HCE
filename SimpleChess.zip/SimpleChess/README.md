# Simple Chess

A UCI chess engine shell in C++20, built on
[Disservin/chess-library](https://github.com/Disservin/chess-library) for board
representation and legal move generation. Tuned for Apple Silicon.

This is the **structural skeleton** for a hand-crafted-evaluation (HCE) engine.
Every core subsystem is present and wired together — the engine already speaks
UCI and plays legal, reasonable chess — but each subsystem is intentionally
minimal so the real work (a strong evaluation, a strong search) can be layered
in without reshaping the architecture.

## Build

No CMake required; the Makefile is the primary path.

```sh
make            # optimized native build -> ./simplechess
make debug      # -O0 -g with ASan/UBSan and assertions
make run        # build and launch (reads UCI on stdin)
make version    # print the current version string
make clean
```

A `CMakeLists.txt` is also provided for IDE/CMake users.

Requires a C++20 compiler (Apple clang works out of the box). The release build
uses `-O3 -flto -mcpu=native`; override the arch with e.g.
`make ARCH="-mcpu=apple-m2"`.

The version string lives in the top-level `VERSION` file (single source of
truth). `make` compiles it into the binary, so every build self-reports its
identity via the UCI `id name` line — which is what lets the versioning tools
below tell builds apart.

## Try it

```
$ ./simplechess
uci
position startpos
go depth 10
```

Point any UCI GUI (Cute Chess, BanksiaGUI, Arena) at the `simplechess` binary.

## Layout

```
src/
  main.cpp        Entry point; sets up stdio and runs the UCI loop.
  uci.hpp/.cpp    UCI protocol: parses commands, owns board/TT/search, options.
  search.hpp/.cpp Stockfish-style alpha-beta on its own thread (see below).
  movepick.hpp/.cpp  Move ordering: TT > good captures > killers > history > bad captures.
  see.hpp/.cpp    Static exchange evaluation (swap algorithm).
  history.hpp     Butterfly/capture/continuation history + countermoves.
  evaluate.hpp/.cpp  HCE surface: tapered material + piece-square tables (grow here).
  tt.hpp/.cpp     Transposition table (probe/store, depth-preferred replacement).
  timeman.hpp/.cpp   Turns `go` clock params into a soft/hard time budget.
  book.hpp/.cpp   Polyglot opening book: hashing, loading, weighted probing.
  polyglot_random.hpp  The 781-constant Polyglot random array (data only).
  version.hpp     Engine identity (name/version/author), baked in at build time.
  types.hpp       Engine-wide types, score conventions, limits.
external/
  chess-library/  Vendored single-header library (include/chess.hpp) + LICENSE.
books/
  book.bin        Default Polyglot opening book, auto-loaded if present.
tools/
  version.py      Versioning framework: build, archive, promote, and compare versions.
  match.py        Engine-vs-engine match runner + Elo estimate.
versions/         Every saved version: binary + metadata + (from v1.0 on) full source.
CHANGELOG.md      Release history — one entry per promoted version.
VERSION           The current version string (single source of truth).
```

Every version — candidates and accepted releases alike — is kept in
`versions/`. The currently *accepted* one is additionally copied to
`./simplechess` at the repo root. That root copy is also the build output, so
working toward the next version (`make`) overwrites it; because the accepted
version is also frozen in `versions/`, that never destroys it. See
"Versioning & strength testing" below.

## Opening book

On startup the engine looks for a Polyglot (`.bin`) book at, in order:
`<exe_dir>/books/book.bin`, `<exe_dir>/book.bin`, `./books/book.bin`,
`./book.bin`. If none exist it plays without a book — silently, not an error.
`go` probes the book before searching; a hit returns instantly as `bestmove`
with no search at all. The moment a position isn't covered, probing simply
returns nothing and normal search takes over for the rest of the game — there's
no explicit "leave book" mode to manage.

Two UCI options control it: `OwnBook` (bool, default true) to disable book use
without unloading it, and `Book File` (string) to point at a different file at
runtime. The position hash used for lookups (`book.cpp`) is a standalone
Polyglot-spec implementation, not a reuse of the engine's internal zobrist key
— it doesn't depend on how the current position was reached, and its random
constants (`polyglot_random.hpp`) were cross-checked against `python-chess`'s
reference implementation and the (independently-implemented) table baked into
the vendored chess-library, so an entry decodes to a legal move — including the
"king captures own rook" castling encoding — on the first try.

## Search techniques

Iterative deepening with aspiration windows drives a PVS negamax featuring: TT
cutoffs and TT-informed static eval, internal iterative reduction, razoring,
reverse futility pruning, null-move pruning, ProbCut, singular extensions with
multicut, log-table late move reductions shaped by history/node type, late move
pruning, futility pruning, SEE pruning of quiets and captures, and a quiescence
search with TT, SEE gating, and delta pruning. Every technique is an isolated,
labelled block in `search.cpp` with its margins collected in the tunables
section at the top of the file — tweak or delete blocks independently.

## Versioning & strength testing

Two tools (both need `python-chess`) turn "did this change help?" into a
one-command, reproducible answer.

### `tools/version.py` — snapshot, test, and promote versions

Every `save` archives a **complete** snapshot — the compiled binary *and* its
buildable source (`src/`, `Makefile`, `CMakeLists.txt`, `VERSION`) — the same
idea as a GitHub release bundling source and binary assets together. A binary
alone can be played and measured, but its source text is gone the moment the
working tree moves on to the next version; archiving the source too means any
past version can still be read, modified, or restored with `restore`, not
just replayed as a black box. (Versions saved before this existed — v0.1
through v0.9 — are binary-only; `list`'s `SRC` column shows which versions
have source archived.)

Two distinct ideas, deliberately kept separate:

- **Saved** (`save`) — a checkpoint in `versions/`. Not every save is good;
  weight sweeps, one-off experiments, and rejected ideas all get saved purely
  so they can be matched against something. These pile up freely, and every
  one stays a runnable binary (plus source, going forward).
- **Promoted** (`promote`) — the accepted version, additionally copied to the
  live `./simplechess` at the repo root and logged to `CHANGELOG.md`. Its
  `versions/` copy is *kept*: root is also the build output and gets
  overwritten by the next `make`, so keeping the frozen copy is what makes the
  accepted version un-loseable. `list` marks the accepted version with `*`.

```sh
# Freeze the current build under a name (defaults to "v<VERSION>"):
python3 tools/version.py save v0.1 -m "baseline"
python3 tools/version.py promote v0.1          # v0.1 -> ./simplechess (and stays in versions/)

# ...edit code, bump the VERSION file, then snapshot the candidate:
python3 tools/version.py save v0.2 -m "add mobility term"

# Test it against the live root version and read off the Elo change:
python3 tools/version.py match v0.2 current --movetime 100 --book-plies 6

# Accepted -> promote installs it at root; versions/v0.2 stays, CHANGELOG.md gets the entry.
python3 tools/version.py promote v0.2

# Or test uncommitted work-in-progress directly against a saved version:
python3 tools/version.py match current v0.1 --depth 8 --book-plies 4

# Go back and look at (or branch off) an old version's actual code:
python3 tools/version.py restore v1.0    # overwrites src/, Makefile, CMakeLists.txt, VERSION
```

Other commands: `list` (every saved version, accepted one marked `*`, source
archived shown in the `SRC` column), `info NAME` (metadata + binary/source
presence), `remove NAME` (delete a version you no longer want). Everything
after the two names in `match` is forwarded to the match runner (below).
`make save NAME=… MSG=…`, `make promote NAME=…`, `make versions`, and
`make version` are thin wrappers. Because the version string is compiled in,
each candidate self-reports its identity, so the match output names them
unambiguously.

### `tools/match.py` — the match runner underneath

Runs an engine-vs-engine match and estimates the Elo gap. Openings are all
unique lines from the Polyglot book up to a chosen ply depth (deduplicated by
transposition); each line is played **twice with colors swapped** for fairness.
It prints the suite size and game count, a per-game running W/D/L tab (from
Engine A's perspective, with clear labels), and a final Elo difference with a
95% confidence interval and likelihood of superiority.

```sh
# Can also be called directly on two binaries:
python3 tools/match.py ./simplechess ./versions/v0.1/simplechess \
    --movetime 100 --book-plies 6
```

`--depth N` isolates per-depth search quality; `--movetime MS` measures real
strength (quality x speed) — pick one. Useful extras: `--max-lines N` (sample
the suite), `--max-plies N` (draw adjudication), `--pgn out.pgn` (save games),
`--hash MB`, `--name-a/--name-b` (labels). Both engines' own books are disabled
during matches so they think for themselves from the suite positions.

## Design notes

- **Threading.** `go` runs the search on a worker thread so the main thread stays
  responsive to `stop`, `isready`, and `quit`. Communication is via two atomics
  (`stop_`, `searching_`); the search polls `stop_` and periodically checks the
  time/node budget.
- **Scores** are centipawns from the side-to-move's perspective. Mates are
  encoded as `VALUE_MATE - ply` (see `types.hpp`) and normalised to root-relative
  when stored in the TT.
- **Move ordering** lives in `movepick.cpp`: TT move, SEE-classified captures
  (good before killers, bad last) ranked by MVV + capture history, killers,
  countermove, then quiets by butterfly + continuation history. A staged
  generator (captures first, quiets lazily) is the natural next optimization
  behind the same `next()` interface.

## Where to extend

| Goal | File | Hook |
|------|------|------|
| Stronger evaluation (mobility, king safety, pawn structure) | `evaluate.cpp` | add terms in `evaluate()` |
| Tune pruning margins / add techniques (correction history, multithreading) | `search.cpp` | tunables block + labelled sections of `negamax()` |
| Staged move generation, better ordering stats | `movepick.cpp`, `history.hpp` | `MovePicker::next()` |
| Smarter time control (PV stability, node ratios) | `timeman.cpp` | `compute_budget()` |
| More UCI options / SPSA-tunable params | `uci.cpp` | `handle_uci` / `handle_setoption` |
| Swap or update the opening book | replace `books/book.bin`, or `setoption name Book File` | — |
| Accept a new version as the live release | `version.py promote vX.Y` (after saving + testing it) | root `./simplechess` + kept in `versions/`, `CHANGELOG.md` |

## Typical change workflow

1. Make your change in `src/`, and bump the `VERSION` file.
2. `python3 tools/version.py save vX.Y -m "…"` — snapshot the candidate.
3. `python3 tools/version.py match vX.Y current --movetime 100 --book-plies 6` — measure it against the live root version (≥200 games recommended for a real signal; use `--depth N` first to isolate eval/search quality from raw speed).
4. If it's an improvement, `version.py promote vX.Y` — it's installed at `./simplechess` (and kept in `versions/`), and the result goes into `CHANGELOG.md`. If not, `version.py remove vX.Y` and try again.

## License

Simple Chess is licensed under the GNU General Public License v3.0 — see
[LICENSE](LICENSE). The vendored `external/chess-library/` is a separate,
MIT-licensed dependency and retains its own license under
`external/chess-library/LICENSE`; MIT code may be freely incorporated into a
GPLv3 project.
