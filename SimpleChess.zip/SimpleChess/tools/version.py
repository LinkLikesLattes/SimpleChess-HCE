#!/usr/bin/env python3
"""
version.py — build, archive, promote, and compare versions of Simple Chess.

A small framework for version testing. Every `save` freezes a *complete*
snapshot of a version: the compiled binary AND its buildable source (src/,
Makefile, CMakeLists.txt, VERSION) — the same idea as a GitHub release
bundling both source and binary assets. A compiled binary alone can be played
and measured, but its source text is gone forever once the working tree moves
on; archiving the source too means any past version can still be read,
modified, or restored into the working tree with `restore`, not just replayed
as a black box.

(Versions saved before this behaviour existed are binary-only — their original
source was already overwritten by later edits with no history to recover it
from, so there was nothing left to archive retroactively.)

You can pit any two saved candidates — or the current working tree — against
each other with the match runner and read off the Elo change, all without
manually copying binaries around.

Two distinct ideas live here, deliberately kept separate:

  * A *saved* version (`save`) is a testing checkpoint. Not every saved
    candidate is good — weight sweeps, one-off experiments, and rejected
    ideas all get saved so they can be matched against something. These pile
    up in versions/ under whatever name you gave them.

  * The *promoted*, or accepted, version is the one currently installed as the
    live binary at the repo root (`./simplechess`). Promoting a saved candidate
    copies its exact tested binary to root and records the promotion in
    CHANGELOG.md — but the version's folder in versions/ is *kept*, not removed.

Every version — accepted or not — therefore always lives in versions/. The
accepted one additionally lives at root. This redundancy is deliberate: root is
also the build output, so a later `make` (working toward the next version)
overwrites ./simplechess. Because the accepted version is also frozen in
versions/, that overwrite can never destroy it — you can always match against
it or re-promote it. `list` marks whichever version is currently live at root.

Commands (run `version.py <command> -h` for details):

    save [NAME] [-m MSG]   build + archive the current source AND binary as NAME
                           (NAME defaults to "v<VERSION>", from the VERSION file)
    restore NAME           copy a version's archived source back onto the
                           working tree (src/, Makefile, CMakeLists.txt, VERSION)
                           — inspect it, modify it, branch off it, rebuild it
    promote NAME           install a saved version as the live ./simplechess
                           and log it to CHANGELOG.md (its versions/ copy stays)
    list                   show all saved versions (the live one is marked)
    info NAME              show one version's metadata
    remove NAME            delete an archived version without promoting it
    match A B [opts...]    play A vs B and report the Elo gap; A or B may be a
                           version name or "current" (builds the working tree).
                           Extra options are forwarded to tools/match.py.
    current                build the working tree and print what it reports

Typical loop:
    version.py save v0.1 -m "baseline: material+PST, full search stack"
    version.py promote v0.1                    # v0.1 becomes ./simplechess
    # ...edit code, bump VERSION, rebuild...
    version.py save v0.2 -m "add mobility term"
    version.py match v0.2 current --movetime 100 --book-plies 6   # vs root
    version.py promote v0.2                    # accepted -> replaces root

    # Later, to go back and look at (or branch off) an old version's code:
    version.py restore v0.2
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VERSIONS_DIR = ROOT / "versions"
MATCH_PY = ROOT / "tools" / "match.py"
CUR_BINARY = ROOT / "simplechess"
VERSION_FILE = ROOT / "VERSION"
CHANGELOG_FILE = ROOT / "CHANGELOG.md"
BINARY_NAME = "simplechess"

# New entries are always spliced in right after this marker (newest first), so
# promote() never has to parse or preserve hand-edited prose above it.
CHANGELOG_MARKER = "<!-- new entries inserted below this line by `version.py promote` -->"
CHANGELOG_TEMPLATE = (
    "# Changelog\n\n"
    "Release history for Simple Chess. An entry is added here whenever a "
    "tested candidate is promoted to the live `simplechess` binary via "
    "`tools/version.py promote`. Every version — accepted or not — is also "
    "kept as a runnable binary in `versions/`.\n\n"
    f"{CHANGELOG_MARKER}\n"
)

# Names that mean "the current working-tree build" instead of a stored version.
CURRENT_ALIASES = {"current", ".", "wip", "working"}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")

# What "the source" means for archiving/restoring: every file whose code is
# actually compiled into the binary (src/ and the header-only vendored
# library — chess-library ships no .cpp, so its code is inlined straight into
# our object files, same as our own headers), plus the build recipes needed to
# reproduce it (Makefile, CMakeLists.txt, VERSION). Deliberately excludes
# books/book.bin: it's read from disk at runtime via ifstream, never compiled
# in, so it isn't part of "the binary" at all — just a sibling data asset.
SOURCE_DIRS  = ["src", "external/chess-library"]
SOURCE_FILES = ["Makefile", "CMakeLists.txt", "VERSION"]


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def die(msg: str) -> "int":
    print(f"error: {msg}", file=sys.stderr)
    return 1


def read_version_file() -> str:
    try:
        return VERSION_FILE.read_text().strip() or "dev"
    except OSError:
        return "dev"


def build_current(clean: bool = True) -> Path:
    """Build the working tree and return the path to the resulting binary.
    A clean build guarantees the binary matches the current source exactly
    (no stale objects), which is what you want when freezing a snapshot."""
    print(f"building current source (VERSION {read_version_file()})"
          f"{' [clean]' if clean else ''} ...", flush=True)
    if clean:
        subprocess.run(["make", "clean"], cwd=ROOT, check=True,
                       stdout=subprocess.DEVNULL)
    proc = subprocess.run(["make"], cwd=ROOT, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True)
    if proc.returncode != 0:
        sys.stdout.write(proc.stdout)
        raise SystemExit(die("build failed"))
    if not CUR_BINARY.exists():
        raise SystemExit(die(f"build succeeded but {CUR_BINARY} is missing"))
    return CUR_BINARY


def query_engine(binary: Path) -> dict:
    """Ask a binary who it is over UCI. Returns {'name', 'author'}."""
    try:
        proc = subprocess.run([str(binary)], input="uci\nquit\n", text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              timeout=10)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"name": f"<unreadable: {type(exc).__name__}>", "author": ""}
    name = author = ""
    for line in proc.stdout.splitlines():
        if line.startswith("id name "):
            name = line[len("id name "):].strip()
        elif line.startswith("id author "):
            author = line[len("id author "):].strip()
    return {"name": name or "?", "author": author}


def version_dir(name: str) -> Path:
    return VERSIONS_DIR / name


def snapshot_source(dest: Path) -> None:
    """Copy the current working tree's buildable source (SOURCE_DIRS +
    SOURCE_FILES) into `dest`, replacing whatever was there before."""
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    for d in SOURCE_DIRS:
        live = ROOT / d
        if live.is_dir():
            shutil.copytree(live, dest / d)
    for f in SOURCE_FILES:
        live = ROOT / f
        if live.is_file():
            shutil.copy2(live, dest / f)


def restore_source(archived: Path) -> None:
    """Copy an archived source/ snapshot back onto the live working tree,
    overwriting src/, Makefile, CMakeLists.txt, VERSION."""
    for d in SOURCE_DIRS:
        src = archived / d
        if src.is_dir():
            live = ROOT / d
            if live.exists():
                shutil.rmtree(live)
            shutil.copytree(src, live)
    for f in SOURCE_FILES:
        src = archived / f
        if src.is_file():
            shutil.copy2(src, ROOT / f)


def load_meta(name: str) -> dict | None:
    meta_path = version_dir(name) / "meta.json"
    if not meta_path.exists():
        return None
    try:
        return json.loads(meta_path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def list_versions() -> list[dict]:
    if not VERSIONS_DIR.exists():
        return []
    out = []
    for d in sorted(VERSIONS_DIR.iterdir()):
        if not d.is_dir():
            continue
        meta = load_meta(d.name)
        if meta:
            meta.setdefault("name", d.name)
            meta["_has_binary"] = (d / BINARY_NAME).exists()
            meta["_has_source"] = (d / "source").is_dir()
            out.append(meta)
    out.sort(key=lambda m: m.get("saved_at", ""))
    return out


def changelog_entry(name: str, meta: dict, ident: dict) -> str:
    saved_at = meta.get("saved_at", "")
    date = saved_at[:10] if saved_at else datetime.now(timezone.utc).date().isoformat()
    message = (meta.get("message") or "").strip() or "(no message recorded)"

    lines = [f"## {name} — {date}", ""]
    lines.append(f"- Self-reports: `{ident.get('name', '?')}`")
    if meta.get("source_version"):
        lines.append(f"- Source VERSION at save time: `{meta['source_version']}`")
    lines.append("")
    lines.append(message)
    return "\n".join(lines)


def append_changelog(name: str, meta: dict, ident: dict) -> None:
    """Insert one entry right after CHANGELOG_MARKER (newest-first). Falls back
    to appending at end-of-file if the marker was hand-edited away, rather
    than failing the promotion over a cosmetic file."""
    text = CHANGELOG_FILE.read_text() if CHANGELOG_FILE.exists() else CHANGELOG_TEMPLATE
    entry = changelog_entry(name, meta, ident)

    if CHANGELOG_MARKER in text:
        text = text.replace(CHANGELOG_MARKER, CHANGELOG_MARKER + "\n\n" + entry, 1)
    else:
        text = text.rstrip("\n") + "\n\n" + entry + "\n"

    CHANGELOG_FILE.write_text(text)


def resolve_binary(name: str, clean: bool) -> tuple[Path, str]:
    """Map a version name (or a 'current' alias) to (binary_path, label)."""
    if name in CURRENT_ALIASES:
        return build_current(clean=clean), "current"
    binary = version_dir(name) / BINARY_NAME
    if not binary.exists():
        available = ", ".join(m["name"] for m in list_versions()) or "(none)"
        raise SystemExit(die(f"no archived binary for version '{name}'. "
                             f"Available: {available}"))
    return binary, name


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------

def cmd_save(args) -> int:
    version = read_version_file()
    name = args.name or f"v{version}"

    if name in CURRENT_ALIASES:
        return die(f"'{name}' is a reserved name")
    if not NAME_RE.match(name):
        return die(f"invalid version name '{name}' "
                   "(use letters, digits, '.', '_', '-')")

    dest = version_dir(name)
    if dest.exists() and not args.force:
        return die(f"version '{name}' already exists (use --force to overwrite)")

    binary = build_current(clean=not args.no_clean)
    ident = query_engine(binary)

    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(binary, dest / BINARY_NAME)
    snapshot_source(dest / "source")  # src/, Makefile, CMakeLists.txt, VERSION

    meta = {
        "name": name,
        "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "message": args.message or "",
        "source_version": version,
        "uci_name": ident["name"],
        "uci_author": ident["author"],
        "binary_size": (dest / BINARY_NAME).stat().st_size,
    }
    (dest / "meta.json").write_text(json.dumps(meta, indent=2) + "\n")

    print(f"\nsaved version '{name}'")
    print(f"  source VERSION : {version}")
    print(f"  self-reports   : {ident['name']}")
    print(f"  message        : {meta['message'] or '(none)'}")
    print(f"  stored at      : {dest}  (binary + full source)")
    if ident["name"] and ident["name"] != f"Simple Chess {version}":
        print("  note: the binary's self-reported name doesn't match VERSION — "
              "did you forget to bump the VERSION file?")
    return 0


def cmd_promote(args) -> int:
    name = args.name
    src_dir = version_dir(name)
    binary = src_dir / BINARY_NAME

    if not binary.exists():
        available = ", ".join(m["name"] for m in list_versions()) or "(none)"
        return die(f"no saved version '{name}' to promote.\n"
                   f"  Save it first:  python3 tools/version.py save {name} -m \"...\"\n"
                   f"  Available: {available}")

    meta = load_meta(name) or {}
    ident = query_engine(binary)

    # Install the tested binary at root, but keep the versions/ copy: root is
    # also the build output and gets overwritten by the next `make`, so the
    # frozen versions/ copy is what makes the accepted version un-loseable.
    shutil.copy2(binary, CUR_BINARY)
    append_changelog(name, meta, ident)

    # Stamp promotion into the version's metadata so `list` can mark it live.
    meta["promoted_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    (src_dir / "meta.json").write_text(json.dumps(meta, indent=2) + "\n")

    print(f"promoted '{name}' -> {CUR_BINARY}")
    print(f"  self-reports  : {ident['name']}")
    print(f"  kept archived : {src_dir}  (root can be rebuilt without losing it)")
    print(f"  logged to     : {CHANGELOG_FILE.name}")

    current_version = read_version_file()
    if ident["name"] and ident["name"] != f"Simple Chess {current_version}":
        print(f"  note: VERSION file currently reads '{current_version}', which "
              f"differs from the promoted binary's '{ident['name']}'. A plain "
              "`make` (or the next `save`) will build that version, not what's "
              "now live at root, until VERSION is updated to match.")
    return 0


def cmd_restore(args) -> int:
    name = args.name
    archived = version_dir(name) / "source"

    if not archived.is_dir():
        return die(f"no source archived for version '{name}' — it's binary-only "
                   "(saved before source archiving existed, or source snapshotting "
                   "failed at save time). It can still be run/matched, just not restored.")

    if not args.yes:
        print(f"This overwrites your working tree — src/, Makefile, CMakeLists.txt, "
              f"VERSION — with version '{name}'s archived source.")
        print("Any uncommitted local changes to those files will be LOST.")
        reply = input("Continue? [y/N] ").strip().lower()
        if reply not in ("y", "yes"):
            print("aborted.")
            return 0

    restore_source(archived)
    print(f"restored '{name}' source into the working tree.")
    print(f"  VERSION now reads: {read_version_file()}")
    print("  Run `make` to build it, or inspect/edit src/ before doing anything else.")
    return 0


def accepted_version(versions: list[dict]) -> str | None:
    """Name of the currently-accepted version: the one promoted most recently.
    Tracks the last promotion, not root's live bytes, so an incidental `make`
    (building toward the next version) doesn't un-mark it."""
    promoted = [m for m in versions if m.get("promoted_at")]
    if not promoted:
        return None
    return max(promoted, key=lambda m: m["promoted_at"])["name"]


def root_matches(name: str) -> bool:
    """Is the live ./simplechess byte-identical to versions/name's binary?
    False means root has drifted to a work-in-progress build."""
    vbin = version_dir(name) / BINARY_NAME
    if not (CUR_BINARY.exists() and vbin.exists()):
        return False
    if CUR_BINARY.stat().st_size != vbin.stat().st_size:
        return False
    return CUR_BINARY.read_bytes() == vbin.read_bytes()


def cmd_list(args) -> int:
    versions = list_versions()
    if not versions:
        print("no versions saved yet.")
        print("save one with:  python3 tools/version.py save v0.1 -m \"...\"")
        return 0

    live = accepted_version(versions)

    headers = ("", "NAME", "VER", "SAVED", "SIZE", "SRC", "UCI NAME", "MESSAGE")
    rows = []
    for m in versions:
        size = m.get("binary_size", 0)
        message = m.get("message", "") or ""
        if not m.get("_has_binary", True):
            message = (message + "  (binary missing)").strip()
        rows.append((
            "*" if m["name"] == live else "",
            m["name"],
            m.get("source_version", "?"),
            m.get("saved_at", "")[:10],
            f"{size / 1024:.0f} KB" if size else "-",
            "yes" if m.get("_has_source") else "no",
            m.get("uci_name", "?")[:40],
            message[:48],
        ))

    # Column widths from content, capped so no single field blows out the table.
    caps = (1, 24, 8, 10, 9, 3, 40, 48)
    widths = [min(cap, max(len(headers[i]), *(len(r[i]) for r in rows)))
              for i, cap in enumerate(caps)]

    def fmt(row):
        return "  ".join(str(c).ljust(widths[i]) for i, c in enumerate(row))

    print(fmt(headers))
    print("  ".join("-" * w for w in widths))
    for r in rows:
        print(fmt(r))
    print(f"\n{len(versions)} version(s) in {VERSIONS_DIR}")

    if live:
        if root_matches(live):
            print(f"* = accepted version ({live}), currently live at ./simplechess")
        else:
            print(f"* = accepted version ({live}); ./simplechess has since been "
                  "rebuilt to a work-in-progress build")
    return 0


def cmd_info(args) -> int:
    meta = load_meta(args.name)
    if meta is None:
        return die(f"no such version '{args.name}'")
    meta.pop("_has_binary", None)
    meta.pop("_has_source", None)
    print(json.dumps(meta, indent=2))
    binary = version_dir(args.name) / BINARY_NAME
    source = version_dir(args.name) / "source"
    print(f"\nbinary: {binary}  ({'present' if binary.exists() else 'MISSING'})")
    print(f"source: {source}  ({'archived — restorable' if source.is_dir() else 'NOT archived (binary-only)'})")
    return 0


def cmd_remove(args) -> int:
    dest = version_dir(args.name)
    if not dest.exists():
        return die(f"no such version '{args.name}'")
    if not args.yes:
        reply = input(f"delete version '{args.name}' at {dest}? [y/N] ").strip().lower()
        if reply not in ("y", "yes"):
            print("aborted.")
            return 0
    shutil.rmtree(dest)
    print(f"removed version '{args.name}'")
    return 0


def cmd_match(args) -> int:
    # Build 'current' at most once even if both sides ask for it.
    bin_a, label_a = resolve_binary(args.a, clean=not args.no_clean)
    if args.b == args.a:
        bin_b, label_b = bin_a, label_a
    else:
        bin_b, label_b = resolve_binary(args.b, clean=not args.no_clean)

    if bin_a == bin_b:
        print("note: both sides resolve to the same binary — expect ~0 Elo "
              "(useful as a sanity check).")

    cmd = [sys.executable, str(MATCH_PY), str(bin_a), str(bin_b),
           "--name-a", label_a, "--name-b", label_b, *args.match_args]
    print(f"running: match {label_a} vs {label_b}\n", flush=True)
    return subprocess.run(cmd).returncode


def cmd_current(args) -> int:
    binary = build_current(clean=not args.no_clean)
    ident = query_engine(binary)
    print(f"\ncurrent working tree:")
    print(f"  VERSION file : {read_version_file()}")
    print(f"  self-reports : {ident['name']}")
    print(f"  binary       : {binary}")
    return 0


# --------------------------------------------------------------------------
# Argument parsing
# --------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="version.py",
        description="Build, archive (source + binary), restore, and compare versions "
                    "of Simple Chess.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="See the module docstring / README for the full workflow.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("save", help="build current source and archive it")
    p.add_argument("name", nargs="?", help="version name (default: v<VERSION>)")
    p.add_argument("-m", "--message", default="", help="what changed in this version")
    p.add_argument("--force", action="store_true", help="overwrite an existing version")
    p.add_argument("--no-clean", action="store_true",
                   help="skip 'make clean' before building (faster, less safe)")
    p.set_defaults(func=cmd_save)

    p = sub.add_parser("promote", help="install a saved version as the live ./simplechess",
                       description="Copies versions/NAME/simplechess to the repo root and "
                                   "logs its message/metadata to CHANGELOG.md. The "
                                   "versions/NAME/ entry is KEPT, so the accepted version "
                                   "survives a later rebuild of ./simplechess. NAME must "
                                   "already exist — promote a version you've already "
                                   "`save`d and tested.")
    p.add_argument("name", help="version to promote (must already be saved)")
    p.set_defaults(func=cmd_promote)

    p = sub.add_parser("restore", help="restore a version's archived source onto the working tree",
                       description="Copies versions/NAME/source/ (src/, Makefile, "
                                   "CMakeLists.txt, VERSION) back onto the live working "
                                   "tree, OVERWRITING those files. Use it to read, modify, "
                                   "or branch off a past version's exact code. Only works "
                                   "for versions saved with source archiving (see `list`'s "
                                   "SRC column). Requires confirmation unless -y.")
    p.add_argument("name", help="version to restore (must have archived source)")
    p.add_argument("-y", "--yes", action="store_true", help="don't prompt")
    p.set_defaults(func=cmd_restore)

    p = sub.add_parser("list", help="list saved versions (accepted one marked *)")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("info", help="show one version's metadata")
    p.add_argument("name")
    p.set_defaults(func=cmd_info)

    p = sub.add_parser("remove", help="delete an archived version")
    p.add_argument("name")
    p.add_argument("-y", "--yes", action="store_true", help="don't prompt")
    p.set_defaults(func=cmd_remove)

    p = sub.add_parser("match", help="play A vs B and report the Elo gap",
                       description="A and B may be version names or 'current' "
                                   "(builds the working tree). Any option this "
                                   "command doesn't recognise is passed through "
                                   "to match.py, e.g. --movetime 100 --book-plies 6.")
    p.add_argument("a", help="engine A (candidate); version name or 'current'")
    p.add_argument("b", help="engine B (baseline); version name or 'current'")
    p.add_argument("--no-clean", action="store_true",
                   help="skip 'make clean' when building 'current'")
    p.set_defaults(func=cmd_match)

    p = sub.add_parser("current", help="build the working tree and show its identity")
    p.add_argument("--no-clean", action="store_true", help="skip 'make clean'")
    p.set_defaults(func=cmd_current)

    return ap


def main() -> int:
    parser = build_parser()
    # parse_known_args lets `match` forward the flags it doesn't define straight
    # to match.py, in order, without a greedy REMAINDER swallowing this command's
    # own options (e.g. --no-clean) too.
    args, extras = parser.parse_known_args()
    if args.cmd == "match":
        args.match_args = extras
    elif extras:
        parser.error(f"unrecognized arguments: {' '.join(extras)}")
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
