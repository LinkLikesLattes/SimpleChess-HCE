#!/usr/bin/env python3
"""
match.py — engine vs engine match runner for gauging strength changes.

Plays two UCI engines against each other across a suite of opening lines
extracted from a Polyglot book, with colors swapped on every opening so both
engines defend the same positions. Reports a running W/D/L tab and, at the
end, the Elo difference implied by the score (with a 95% confidence interval
and likelihood of superiority).

Typical workflow:
    cp simplechess simplechess-base          # snapshot before making changes
    ... hack on the engine, rebuild ...
    python3 tools/match.py ./simplechess ./simplechess-base \
        --movetime 100 --book-plies 6

Engine A (first argument) is the candidate / new version; Engine B is the
baseline. The final Elo number is from A's perspective: positive means the
new version is stronger.

Fixed-depth (--depth) compares per-depth search quality independent of speed;
fixed-movetime (--movetime) compares real playing strength (quality x speed).
"""

import argparse
import math
import random
import sys
import time
from pathlib import Path

import chess
import chess.engine
import chess.pgn
import chess.polyglot

# Both engines' own books are disabled for the match (when they expose an
# OwnBook option): openings come from the suite, thinking must be their own.


# --------------------------------------------------------------------------
# Opening suite extraction
# --------------------------------------------------------------------------

def collect_book_lines(book_path: Path, max_plies: int) -> list[list[chess.Move]]:
    """Walk the book tree from the start position and return every line of up
    to `max_plies` plies (shorter if the book runs out first). Lines whose
    final positions transpose into one another are deduplicated so no opening
    is played twice."""
    lines: list[list[chess.Move]] = []
    seen_final: set[int] = set()

    with chess.polyglot.open_reader(book_path) as reader:

        def walk(board: chess.Board, moves: list[chess.Move]) -> None:
            entries = []
            if len(moves) < max_plies:
                entries = [e for e in reader.find_all(board) if board.is_legal(e.move)]
                # Deterministic order: heaviest lines first, ties by move text.
                entries.sort(key=lambda e: (-e.weight, e.move.uci()))

            if not entries:  # leaf: book exhausted or depth reached
                key = chess.polyglot.zobrist_hash(board)
                if key not in seen_final:
                    seen_final.add(key)
                    lines.append(list(moves))
                return

            for e in entries:
                board.push(e.move)
                moves.append(e.move)
                walk(board, moves)
                moves.pop()
                board.pop()

        walk(chess.Board(), [])

    return lines


def line_to_san(moves: list[chess.Move]) -> str:
    board = chess.Board()
    parts = []
    for m in moves:
        if board.turn == chess.WHITE:
            parts.append(f"{board.fullmove_number}.")
        parts.append(board.san(m))
        board.push(m)
    return " ".join(parts) if parts else "(start position)"


# --------------------------------------------------------------------------
# Engine management
# --------------------------------------------------------------------------

class Player:
    """A UCI engine process with a stable label, restartable after a crash."""

    def __init__(self, path: Path, label: str, hash_mb: int | None, threads: int | None = None):
        self.path = path
        self.label = label
        self.hash_mb = hash_mb
        self.threads = threads
        self.engine: chess.engine.SimpleEngine | None = None
        self.id_name = "?"
        self.spawn()

    def spawn(self) -> None:
        self.engine = chess.engine.SimpleEngine.popen_uci(str(self.path))
        self.id_name = self.engine.id.get("name", "?")
        opts = {}
        if "OwnBook" in self.engine.options:
            opts["OwnBook"] = False  # openings come from the suite, not the engine
        if self.hash_mb is not None and "Hash" in self.engine.options:
            opts["Hash"] = self.hash_mb
        # Older binaries advertise a Threads option pinned at max=1 (predating
        # SMP support), so a presence check alone isn't enough — python-chess
        # raises if the requested value exceeds the engine's own advertised
        # max. Clamping to that max is what makes --threads safe to pass
        # uniformly across a gauntlet spanning versions with and without SMP.
        if self.threads is not None and "Threads" in self.engine.options:
            opt = self.engine.options["Threads"]
            clamped = self.threads
            if opt.max is not None:
                clamped = min(clamped, opt.max)
            if opt.min is not None:
                clamped = max(clamped, opt.min)
            opts["Threads"] = clamped
        if opts:
            self.engine.configure(opts)

    def respawn(self) -> None:
        try:
            if self.engine is not None:
                self.engine.quit()
        except chess.engine.EngineError:
            pass
        self.spawn()

    def quit(self) -> None:
        try:
            if self.engine is not None:
                self.engine.quit()
        except chess.engine.EngineError:
            pass


# --------------------------------------------------------------------------
# Game play
# --------------------------------------------------------------------------

def game_over_reason(board: chess.Board) -> str:
    if board.is_checkmate():
        return "checkmate"
    if board.is_stalemate():
        return "stalemate"
    if board.is_insufficient_material():
        return "insufficient material"
    if board.can_claim_fifty_moves() or board.is_seventyfive_moves():
        return "fifty-move rule"
    if board.can_claim_threefold_repetition() or board.is_fivefold_repetition():
        return "repetition"
    return "game over"


def play_game(white: Player, black: Player, opening: list[chess.Move],
              limit: chess.engine.Limit, max_plies: int, game_key: str):
    """Play one game from the given opening. Returns (result, reason, board)
    where result is '1-0', '0-1', or '1/2-1/2'."""
    board = chess.Board()
    for m in opening:
        board.push(m)

    while True:
        if board.is_game_over(claim_draw=True):
            return board.result(claim_draw=True), game_over_reason(board), board
        if board.ply() >= max_plies:
            return "1/2-1/2", f"adjudicated draw at {max_plies} plies", board

        mover = white if board.turn == chess.WHITE else black
        try:
            played = mover.engine.play(board, limit, game=game_key)
        except chess.engine.EngineError as exc:
            # Crash / protocol failure loses the game for the mover.
            result = "0-1" if board.turn == chess.WHITE else "1-0"
            mover.respawn()
            return result, f"{mover.label} failed ({type(exc).__name__})", board

        if played.move is None or played.move not in board.legal_moves:
            result = "0-1" if board.turn == chess.WHITE else "1-0"
            return result, f"{mover.label} played an illegal move", board

        board.push(played.move)


# --------------------------------------------------------------------------
# Elo math
# --------------------------------------------------------------------------

def score_to_elo(p: float) -> float:
    if p <= 0.0:
        return -math.inf
    if p >= 1.0:
        return math.inf
    return -400.0 * math.log10(1.0 / p - 1.0)


def fmt_elo(e: float) -> str:
    if math.isinf(e):
        return ">+1000" if e > 0 else "<-1000"
    return f"{e:+.0f}"


def elo_summary(w: int, d: int, l: int):
    """Elo difference with 95% CI and likelihood of superiority, from the
    perspective of the engine whose wins are `w`."""
    n = w + d + l
    if n == 0:
        return None
    p = (w + 0.5 * d) / n
    elo = score_to_elo(p)

    # Normal approximation on the per-game score {1, 0.5, 0}.
    ex2 = (w + 0.25 * d) / n
    var = max(ex2 - p * p, 0.0)
    se = math.sqrt(var / n)
    lo = score_to_elo(max(p - 1.96 * se, 0.0))
    hi = score_to_elo(min(p + 1.96 * se, 1.0))

    los = 0.5 * (1.0 + math.erf((w - l) / math.sqrt(2.0 * (w + l)))) if (w + l) > 0 else 0.5
    return p, elo, lo, hi, los


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="Engine vs engine match with book openings and Elo estimate.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("engine_a", type=Path, help="candidate / NEW engine binary")
    ap.add_argument("engine_b", type=Path, help="baseline / OLD engine binary")
    ap.add_argument("--depth", type=int, help="fixed 'go depth N' per move")
    ap.add_argument("--movetime", type=int, help="fixed 'go movetime MS' per move (milliseconds)")
    ap.add_argument("--book", type=Path, default=None,
                    help="Polyglot book (default: books/book.bin next to the project)")
    ap.add_argument("--book-plies", type=int, default=None,
                    help="extract all unique book lines up to this many plies")
    ap.add_argument("--max-lines", type=int, default=None,
                    help="randomly sample at most this many lines from the suite")
    ap.add_argument("--max-plies", type=int, default=400,
                    help="adjudicate a draw beyond this many total plies")
    ap.add_argument("--hash", type=int, default=None, help="Hash MB for both engines")
    ap.add_argument("--threads", type=int, default=None,
                    help="Threads for both engines (ignored by binaries with no Threads option)")
    ap.add_argument("--seed", type=int, default=42, help="random seed for --max-lines sampling")
    ap.add_argument("--pgn", type=Path, default=None, help="append played games to this PGN file")
    ap.add_argument("--name-a", default=None, help="display label for engine A (e.g. a version name)")
    ap.add_argument("--name-b", default=None, help="display label for engine B")
    args = ap.parse_args()

    if args.depth is not None and args.movetime is not None:
        ap.error("choose either --depth or --movetime, not both")

    # Interactive fallbacks so the script is usable without memorizing flags.
    if args.depth is None and args.movetime is None:
        if not sys.stdin.isatty():
            ap.error("provide --depth or --movetime")
        mode = input("Per-move limit — [d]epth or [m]ovetime? ").strip().lower()
        if mode.startswith("d"):
            args.depth = int(input("go depth: ").strip())
        else:
            args.movetime = int(input("go movetime (ms): ").strip())

    if args.book_plies is None:
        if not sys.stdin.isatty():
            ap.error("provide --book-plies")
        args.book_plies = int(input("Book line depth (plies): ").strip())

    if args.book is None:
        args.book = Path(__file__).resolve().parent.parent / "books" / "book.bin"

    return args


def main() -> int:
    args = parse_args()

    # Absolute paths: Path("./x") normalizes to "x", which subprocess would
    # then look up in $PATH rather than the working directory.
    args.engine_a = args.engine_a.resolve()
    args.engine_b = args.engine_b.resolve()

    for path in (args.engine_a, args.engine_b):
        if not path.exists():
            print(f"error: engine not found: {path}", file=sys.stderr)
            return 1
    if not args.book.exists():
        print(f"error: book not found: {args.book}", file=sys.stderr)
        return 1

    if args.depth is not None:
        limit = chess.engine.Limit(depth=args.depth)
        limit_desc = f"go depth {args.depth}"
    else:
        limit = chess.engine.Limit(time=args.movetime / 1000.0)
        limit_desc = f"go movetime {args.movetime}"

    # ---- Build the opening suite ----
    lines = collect_book_lines(args.book, args.book_plies)
    total_unique = len(lines)
    if args.max_lines is not None and args.max_lines < total_unique:
        random.Random(args.seed).shuffle(lines)
        lines = sorted(lines[: args.max_lines], key=lambda ms: [m.uci() for m in ms])
    games_total = 2 * len(lines)

    # Prefer caller-supplied labels (e.g. version names from version.py); fall
    # back to the binary filenames, disambiguating if they collide.
    name_a = args.name_a or args.engine_a.name
    name_b = args.name_b or args.engine_b.name
    if name_a == name_b:
        name_a += "(A)"
        name_b += "(B)"
    label_a = f"A:{name_a}"
    label_b = f"B:{name_b}"

    print("=" * 72)
    print("ENGINE MATCH")
    print(f"  Engine A (new/candidate): {label_a}  [{args.engine_a}]")
    print(f"  Engine B (baseline):      {label_b}  [{args.engine_b}]")
    print(f"  Per-move limit:           {limit_desc}")
    if args.threads is not None:
        print(f"  Threads (if supported):   {args.threads}")
    print(f"  Opening book:             {args.book}")
    print(f"  Unique lines up to {args.book_plies} plies: {total_unique}"
          + (f"  (sampled down to {len(lines)})" if len(lines) != total_unique else ""))
    print(f"  Games to play:            {games_total}  (each line once per color)")
    print(f"  Draw adjudication:        {args.max_plies} plies")
    print("=" * 72)

    player_a = Player(args.engine_a, label_a, args.hash, args.threads)
    player_b = Player(args.engine_b, label_b, args.hash, args.threads)
    print(f"  A reports: id name {player_a.id_name}")
    print(f"  B reports: id name {player_b.id_name}")
    print("-" * 72)

    # W/D/L from A's perspective, plus per-color breakdown for A.
    w = d = l = 0
    aw = [0, 0, 0]  # A as white: [win, draw, loss]
    ab = [0, 0, 0]  # A as black
    game_no = 0
    start = time.monotonic()

    pgn_file = open(args.pgn, "a") if args.pgn else None

    try:
        for line_idx, opening in enumerate(lines, 1):
            san = line_to_san(opening)
            for a_is_white in (True, False):
                game_no += 1
                white, black = (player_a, player_b) if a_is_white else (player_b, player_a)
                result, reason, board = play_game(
                    white, black, opening, limit, args.max_plies, f"g{game_no}")

                # Tally from A's perspective.
                if result == "1/2-1/2":
                    d += 1
                    outcome_a = "draw"
                    (aw if a_is_white else ab)[1] += 1
                elif (result == "1-0") == a_is_white:
                    w += 1
                    outcome_a = f"{label_a} wins"
                    (aw if a_is_white else ab)[0] += 1
                else:
                    l += 1
                    outcome_a = f"{label_b} wins"
                    (aw if a_is_white else ab)[2] += 1

                stats = elo_summary(w, d, l)
                elo_txt = fmt_elo(stats[1]) if stats else "n/a"
                moves_played = (board.ply() - len(opening) + 1) // 2
                print(f"[{game_no:>3}/{games_total}] line {line_idx:>3}: {san:<34.34} | "
                      f"White={white.label:<22.22} | {result:^7} {outcome_a}, {reason}, "
                      f"{moves_played} moves | A: +{w} ={d} -{l} | Elo {elo_txt}",
                      flush=True)

                if pgn_file:
                    game = chess.pgn.Game.from_board(board)
                    game.headers["Event"] = f"match {label_a} vs {label_b} ({limit_desc})"
                    game.headers["Round"] = str(game_no)
                    game.headers["White"] = white.label
                    game.headers["Black"] = black.label
                    game.headers["Result"] = result
                    game.headers["Opening"] = san
                    game.headers["Termination"] = reason
                    print(game, file=pgn_file, end="\n\n", flush=True)
    except KeyboardInterrupt:
        print("\nInterrupted — reporting partial results.", flush=True)
    finally:
        player_a.quit()
        player_b.quit()
        if pgn_file:
            pgn_file.close()

    elapsed = time.monotonic() - start
    n = w + d + l
    print("=" * 72)
    print("MATCH RESULT")
    print(f"  {label_a}  vs  {label_b}")
    print(f"  Games played: {n}/{games_total}   ({elapsed:.0f}s)")
    if n == 0:
        print("  No games completed.")
        return 0
    stats = elo_summary(w, d, l)
    p, elo, lo, hi, los = stats
    print(f"  {label_a}: +{w} ={d} -{l}   score {100 * p:.1f}%")
    print(f"    as White: +{aw[0]} ={aw[1]} -{aw[2]}   as Black: +{ab[0]} ={ab[1]} -{ab[2]}")
    print(f"  Elo difference (A - B): {fmt_elo(elo)}  "
          f"[95% CI {fmt_elo(lo)} .. {fmt_elo(hi)}]   LOS {100 * los:.1f}%")

    if lo > 0:
        verdict = f"{label_a} is STRONGER (statistically significant at 95%)"
    elif hi < 0:
        verdict = f"{label_a} is WEAKER (statistically significant at 95%)"
    else:
        verdict = "no statistically significant difference yet (CI includes 0 — play more games)"
    print(f"  Verdict: {verdict}")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
